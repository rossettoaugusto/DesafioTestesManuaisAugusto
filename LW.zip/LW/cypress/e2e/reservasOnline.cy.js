describe('Acessar o Reservas Online', () => {
    it('Adicionar reservas periodo de 5 dias', () => {
        cy.visit('https://reservas.desbravador.com.br/hotel-app/hotel-teste-desbravador-8050');
        cy.contains('Verificar Disponibilidade').click();
    });
    
});