describe('Acesso LW', () => {
  it('Login', () => {
    cy.visit('https://reservas.desbravador.com.br/hotel-app/hotel-teste-desbravador-8050')
    cy.get('input[type=email]').type('cliente_9001_11@developer.com')
    cy.get('input[type=password]').type('teste')
    cy.contains('Entrar').click()
    cy.contains('Entrar').click()
    cy.wait(6000)
  })

})

